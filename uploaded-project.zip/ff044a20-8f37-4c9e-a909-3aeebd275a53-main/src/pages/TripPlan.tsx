import Navbar from "@/components/Navbar";
import { StepByStepTripPlanner } from "@/components/StepByStepTripPlanner";

const TripPlan = () => {

  return (
    <div className="min-h-screen bg-gradient-to-br from-ocean-50 to-sunset-50">
      <Navbar />
      
      <div className="container mx-auto px-4 py-24">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-ocean-600 to-sunset-600 bg-clip-text text-transparent mb-4">
            Plan Your Perfect Trip
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Tell us about your dream destination and we'll create a personalized itinerary just for you
          </p>
        </div>

        <StepByStepTripPlanner />
      </div>
    </div>
  );
};

export default TripPlan;