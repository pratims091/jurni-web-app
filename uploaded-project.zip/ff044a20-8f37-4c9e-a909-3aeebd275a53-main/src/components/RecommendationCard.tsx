import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Sparkles, TrendingUp, Star } from "lucide-react";
import { cn } from "@/lib/utils";

interface Recommendation {
  id: string;
  title: string;
  description: string;
  type: "popular" | "trending" | "premium";
  tags?: string[];
  price?: string;
  rating?: number;
}

interface RecommendationCardProps {
  recommendations: Recommendation[];
  onSelect?: (recommendation: Recommendation) => void;
  className?: string;
}

export const RecommendationCard = ({ recommendations, onSelect, className }: RecommendationCardProps) => {
  if (recommendations.length === 0) return null;

  const getTypeIcon = (type: Recommendation["type"]) => {
    switch (type) {
      case "popular":
        return <TrendingUp className="w-4 h-4" />;
      case "trending":
        return <Sparkles className="w-4 h-4" />;
      case "premium":
        return <Star className="w-4 h-4" />;
    }
  };

  const getTypeColor = (type: Recommendation["type"]) => {
    switch (type) {
      case "popular":
        return "bg-blue-50 text-blue-700 border-blue-200";
      case "trending":
        return "bg-purple-50 text-purple-700 border-purple-200";
      case "premium":
        return "bg-amber-50 text-amber-700 border-amber-200";
    }
  };

  return (
    <Card className={cn("backdrop-blur-lg bg-white/90 border-white/30 shadow-lg", className)}>
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <Sparkles className="w-5 h-5 text-ocean-600" />
          AI Recommendations
        </CardTitle>
        <CardDescription>
          Based on your preferences, here are some suggestions
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {recommendations.map((rec) => (
          <div
            key={rec.id}
            className="p-4 rounded-lg border border-gray-100 hover:border-ocean-200 transition-colors group cursor-pointer"
            onClick={() => onSelect?.(rec)}
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="font-medium text-gray-900 group-hover:text-ocean-600 transition-colors">
                    {rec.title}
                  </h4>
                  <Badge variant="outline" className={cn("text-xs", getTypeColor(rec.type))}>
                    <span className="mr-1">{getTypeIcon(rec.type)}</span>
                    {rec.type}
                  </Badge>
                </div>
                <p className="text-sm text-gray-600 mb-2">{rec.description}</p>
                
                {rec.tags && (
                  <div className="flex flex-wrap gap-1 mb-2">
                    {rec.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                )}
                
                <div className="flex items-center gap-3 text-sm">
                  {rec.price && (
                    <span className="font-medium text-ocean-600">{rec.price}</span>
                  )}
                  {rec.rating && (
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      <span className="text-gray-600">{rec.rating}</span>
                    </div>
                  )}
                </div>
              </div>
              
              {onSelect && (
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="opacity-0 group-hover:opacity-100 transition-opacity ml-3"
                >
                  Select
                </Button>
              )}
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  );
};