import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-travel.jpg";

const HeroSection = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          backgroundRepeat: 'no-repeat'
        }}
      >
        <div className="absolute inset-0 bg-black/40 backdrop-blur-[1px]" />
      </div>
      
      {/* Hero Content */}
      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-md border border-white/20 text-white/90 mb-6 animate-float">
          <Sparkles className="w-4 h-4" />
          <span className="text-sm font-medium">Powered by Advanced AI</span>
        </div>
        
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
          Plan Your Perfect
          <span className="block bg-gradient-sunset bg-clip-text text-transparent">
            AI-Powered Trip
          </span>
        </h1>
        
        <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
          Let our intelligent AI assistant create personalized itineraries, find hidden gems, 
          and turn your travel dreams into unforgettable experiences.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link to="/plan">
            <Button variant="hero" size="lg" className="text-lg px-8 py-6">
              Start Planning Now
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
          
          <Button variant="glass" size="lg" className="text-lg px-8 py-6">
            Watch Demo
          </Button>
        </div>
        
        <div className="mt-12 text-white/70 text-sm">
          ✨ No credit card required • 🌍 Plan unlimited trips • 🎯 Personalized recommendations
        </div>
      </div>
      
      {/* Floating Elements */}
      <div className="absolute top-20 left-10 w-20 h-20 bg-gradient-sunset rounded-full opacity-20 animate-float" style={{ animationDelay: '0.5s' }} />
      <div className="absolute bottom-20 right-10 w-16 h-16 bg-gradient-ocean rounded-full opacity-20 animate-float" style={{ animationDelay: '1s' }} />
    </section>
  );
};

export default HeroSection;