import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { 
  MapPin, Calendar, Users, DollarSign, Plane, Utensils, 
  Home, Compass, ChevronRight, ChevronLeft, Baby, Heart 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { StepIndicator } from "./StepIndicator";
import { RecommendationCard } from "./RecommendationCard";

// Individual step schemas
const destinationSchema = z.object({
  destination: z.string().min(1, "Destination is required"),
  departureCity: z.string().min(1, "Departure city is required"),
});

const durationSchema = z.object({
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
});

const travelersSchema = z.object({
  adults: z.number().min(1, "At least one adult is required"),
  children: z.array(z.number()).optional(),
  pets: z.boolean().optional(),
  petDetails: z.string().optional(),
});

const budgetSchema = z.object({
  amount: z.string().min(1, "Budget amount is required"),
  currency: z.string().min(1, "Currency is required"),
});

const preferencesSchema = z.object({
  stayPreferences: z.array(z.string()).min(1, "Please select at least one stay preference"),
  travelPreferences: z.array(z.string()).min(1, "Please select at least one travel preference"),
  foodPreferences: z.array(z.string()).optional(),
  themes: z.array(z.string()).optional(),
});

const additionalSchema = z.object({
  additionalRequests: z.string().optional(),
});

// Combined type for all form data
type TripPlanData = {
  destination?: z.infer<typeof destinationSchema>;
  duration?: z.infer<typeof durationSchema>;
  travelers?: z.infer<typeof travelersSchema>;
  budget?: z.infer<typeof budgetSchema>;
  preferences?: z.infer<typeof preferencesSchema>;
  additional?: z.infer<typeof additionalSchema>;
};

const STEPS = [
  "Destination",
  "Duration", 
  "Travelers",
  "Budget",
  "Preferences",
  "Review"
];

export const StepByStepTripPlanner = () => {
  const [currentStep, setCurrentStep] = useState(0);
  const [completedSteps, setCompletedSteps] = useState<number[]>([]);
  const [formData, setFormData] = useState<TripPlanData>({});
  const [childrenAges, setChildrenAges] = useState<number[]>([]);
  const [showPetDetails, setShowPetDetails] = useState(false);

  // Individual form instances for each step
  const destinationForm = useForm<z.infer<typeof destinationSchema>>({
    resolver: zodResolver(destinationSchema),
    defaultValues: formData.destination || {},
  });

  const durationForm = useForm<z.infer<typeof durationSchema>>({
    resolver: zodResolver(durationSchema),
    defaultValues: formData.duration || {},
  });

  const travelersForm = useForm<z.infer<typeof travelersSchema>>({
    resolver: zodResolver(travelersSchema),
    defaultValues: formData.travelers || { adults: 1, children: [], pets: false },
  });

  const budgetForm = useForm<z.infer<typeof budgetSchema>>({
    resolver: zodResolver(budgetSchema),
    defaultValues: formData.budget || {},
  });

  const preferencesForm = useForm<z.infer<typeof preferencesSchema>>({
    resolver: zodResolver(preferencesSchema),
    defaultValues: formData.preferences || { 
      stayPreferences: [], 
      travelPreferences: [], 
      foodPreferences: [], 
      themes: [] 
    },
  });

  const additionalForm = useForm<z.infer<typeof additionalSchema>>({
    resolver: zodResolver(additionalSchema),
    defaultValues: formData.additional || {},
  });

  const getCurrentForm = () => {
    switch (currentStep) {
      case 0: return destinationForm;
      case 1: return durationForm;
      case 2: return travelersForm;
      case 3: return budgetForm;
      case 4: return preferencesForm;
      case 5: return additionalForm;
      default: return destinationForm;
    }
  };

  // Mock recommendations based on current step and previous inputs
  const getRecommendations = () => {
    switch (currentStep) {
      case 0: // Destination
        return [
          {
            id: "1",
            title: "Paris, France",
            description: "City of Love with iconic landmarks, museums, and cuisine",
            type: "popular" as const,
            tags: ["Culture", "Romance", "Food"],
            rating: 4.8
          },
          {
            id: "2", 
            title: "Tokyo, Japan",
            description: "Modern metropolis blending tradition and innovation",
            type: "trending" as const,
            tags: ["Culture", "Technology", "Food"],
            rating: 4.9
          },
          {
            id: "3",
            title: "Bali, Indonesia", 
            description: "Tropical paradise with beaches, temples, and wellness",
            type: "premium" as const,
            tags: ["Beach", "Wellness", "Nature"],
            rating: 4.7
          }
        ];
      case 2: // Travelers
        if (formData.destination?.destination) {
          return [
            {
              id: "family1",
              title: "Family-Friendly Activities",
              description: `Kid-friendly attractions and activities in ${formData.destination.destination}`,
              type: "popular" as const,
              tags: ["Family", "Activities", "Kids"],
            }
          ];
        }
        break;
      case 3: // Budget
        if (formData.budget?.amount) {
          const amount = parseInt(formData.budget.amount);
          return [
            {
              id: "budget1",
              title: amount > 5000 ? "Luxury Experience" : "Value Travel",
              description: amount > 5000 ? 
                "Premium accommodations and exclusive experiences" : 
                "Great value options without compromising quality",
              type: amount > 5000 ? "premium" as const : "popular" as const,
              price: `${formData.budget.currency} ${amount}`,
            }
          ];
        }
        break;
      default:
        return [];
    }
    return [];
  };

  const saveCurrentStepData = (data: any) => {
    switch (currentStep) {
      case 0:
        setFormData(prev => ({ ...prev, destination: data }));
        break;
      case 1:
        setFormData(prev => ({ ...prev, duration: data }));
        break;
      case 2:
        setFormData(prev => ({ ...prev, travelers: data }));
        break;
      case 3:
        setFormData(prev => ({ ...prev, budget: data }));
        break;
      case 4:
        setFormData(prev => ({ ...prev, preferences: data }));
        break;
      case 5:
        setFormData(prev => ({ ...prev, additional: data }));
        break;
    }
  };

  const nextStep = async () => {
    const currentForm = getCurrentForm();
    const isValid = await currentForm.trigger();
    if (isValid) {
      const currentData = currentForm.getValues();
      saveCurrentStepData(currentData);
      
      if (!completedSteps.includes(currentStep)) {
        setCompletedSteps(prev => [...prev, currentStep]);
      }
      
      if (currentStep < STEPS.length - 1) {
        setCurrentStep(currentStep + 1);
      }
    }
  };

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const addChildAge = () => {
    const newAges = [...childrenAges, 0];
    setChildrenAges(newAges);
    travelersForm.setValue("children", newAges);
  };

  const removeChildAge = (index: number) => {
    const newAges = childrenAges.filter((_, i) => i !== index);
    setChildrenAges(newAges);
    travelersForm.setValue("children", newAges);
  };

  const updateChildAge = (index: number, age: number) => {
    const newAges = [...childrenAges];
    newAges[index] = age;
    setChildrenAges(newAges);
    travelersForm.setValue("children", newAges);
  };

  const onSubmit = (data: any) => {
    saveCurrentStepData(data);
    console.log("Final trip data:", { ...formData, additional: data });
    // Handle final submission
  };

  const renderStepContent = () => {
    const currentForm = getCurrentForm();
    
    switch (currentStep) {
      case 0: // Destination
        return (
          <Form {...destinationForm}>
            <form onSubmit={destinationForm.handleSubmit(nextStep)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={destinationForm.control}
                  name="destination"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <MapPin className="h-4 w-4" />
                        Where do you want to go?
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Paris, France" {...field} />
                      </FormControl>
                      <FormDescription>Enter your dream destination</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={destinationForm.control}
                  name="departureCity"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Plane className="h-4 w-4" />
                        Departure City/Airport
                      </FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., New York, JFK" {...field} />
                      </FormControl>
                      <FormDescription>Where will you start your journey?</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </form>
          </Form>
        );

      case 1: // Duration
        return (
          <Form {...durationForm}>
            <form onSubmit={durationForm.handleSubmit(nextStep)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={durationForm.control}
                  name="startDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Calendar className="h-4 w-4" />
                        Start Date
                      </FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={durationForm.control}
                  name="endDate"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>End Date</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </form>
          </Form>
        );

      case 2: // Travelers
        return (
          <Form {...travelersForm}>
            <form onSubmit={travelersForm.handleSubmit(nextStep)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={travelersForm.control}
                  name="adults"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <Users className="h-4 w-4" />
                        Number of Adults
                      </FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          min="1" 
                          {...field} 
                          onChange={(e) => field.onChange(parseInt(e.target.value))}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="space-y-3">
                  <FormLabel className="flex items-center gap-2">
                    <Baby className="h-4 w-4" />
                    Children (with ages)
                  </FormLabel>
                  {childrenAges.map((age, index) => (
                    <div key={index} className="flex gap-2">
                      <Input
                        type="number"
                        min="0"
                        max="17"
                        value={age}
                        onChange={(e) => updateChildAge(index, parseInt(e.target.value))}
                        placeholder="Age"
                        className="w-20"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeChildAge(index)}
                      >
                        Remove
                      </Button>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addChildAge}
                  >
                    Add Child
                  </Button>
                </div>
              </div>

              <div className="space-y-3">
                <FormField
                  control={travelersForm.control}
                  name="pets"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                      <FormControl>
                        <Checkbox
                          checked={field.value || false}
                          onCheckedChange={(checked) => {
                            field.onChange(checked);
                            setShowPetDetails(!!checked);
                          }}
                        />
                      </FormControl>
                      <div className="space-y-1 leading-none">
                        <FormLabel className="flex items-center gap-2">
                          <Heart className="h-4 w-4" />
                          Traveling with pets
                        </FormLabel>
                      </div>
                    </FormItem>
                  )}
                />

                {showPetDetails && (
                  <FormField
                    control={travelersForm.control}
                    name="petDetails"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="Pet details (type, size, special needs)" {...field} />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                )}
              </div>
            </form>
          </Form>
        );

      case 3: // Budget
        return (
          <Form {...budgetForm}>
            <form onSubmit={budgetForm.handleSubmit(nextStep)} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <FormField
                  control={budgetForm.control}
                  name="amount"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="flex items-center gap-2">
                        <DollarSign className="h-4 w-4" />
                        Budget Amount
                      </FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="5000" {...field} />
                      </FormControl>
                      <FormDescription>Total budget for your trip</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={budgetForm.control}
                  name="currency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Currency</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select currency" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="USD">USD ($)</SelectItem>
                          <SelectItem value="EUR">EUR (€)</SelectItem>
                          <SelectItem value="GBP">GBP (£)</SelectItem>
                          <SelectItem value="JPY">JPY (¥)</SelectItem>
                          <SelectItem value="CAD">CAD (C$)</SelectItem>
                          <SelectItem value="AUD">AUD (A$)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
            </form>
          </Form>
        );

      case 4: // Preferences
        const stayOptions = [
          "Hotel", "Resort", "Hostel", "Vacation Rental", "Boutique Hotel", 
          "Luxury Resort", "Budget Hotel", "Apartment", "Villa", "Camping"
        ];

        const travelOptions = [
          "Flight", "Train", "Bus", "Car Rental", "Private Transfer", 
          "Motorcycle", "Bicycle", "Walking Tours", "Public Transport"
        ];

        const foodOptions = [
          "Local Cuisine", "Vegetarian", "Vegan", "Halal", "Kosher", 
          "Gluten-Free", "Fine Dining", "Street Food", "Fast Food", "Organic"
        ];

        const themeOptions = [
          "Heritage & Culture", "Adventure", "Nightlife", "Beach & Relaxation", 
          "Wildlife & Nature", "Photography", "Food & Wine", "Shopping", 
          "Wellness & Spa", "Family Fun", "Romance", "Business", "Sports"
        ];

        return (
          <Form {...preferencesForm}>
            <form onSubmit={preferencesForm.handleSubmit(nextStep)} className="space-y-8">
              {/* Stay Preferences */}
              <FormField
                control={preferencesForm.control}
                name="stayPreferences"
                render={() => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2 text-base">
                      <Home className="h-4 w-4" />
                      Stay Preferences
                    </FormLabel>
                    <FormDescription>Select your preferred accommodation types</FormDescription>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {stayOptions.map((option) => (
                        <FormField
                          key={option}
                          control={preferencesForm.control}
                          name="stayPreferences"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(option)}
                                  onCheckedChange={(checked) => {
                                    const currentValue = field.value || [];
                                    return checked
                                      ? field.onChange([...currentValue, option])
                                      : field.onChange(currentValue.filter((value: string) => value !== option))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="text-sm font-normal">{option}</FormLabel>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Travel Preferences */}
              <FormField
                control={preferencesForm.control}
                name="travelPreferences"
                render={() => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2 text-base">
                      <Plane className="h-4 w-4" />
                      Transportation Preferences
                    </FormLabel>
                    <FormDescription>Select your preferred modes of transportation</FormDescription>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {travelOptions.map((option) => (
                        <FormField
                          key={option}
                          control={preferencesForm.control}
                          name="travelPreferences"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(option)}
                                  onCheckedChange={(checked) => {
                                    const currentValue = field.value || [];
                                    return checked
                                      ? field.onChange([...currentValue, option])
                                      : field.onChange(currentValue.filter((value: string) => value !== option))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="text-sm font-normal">{option}</FormLabel>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Food Preferences */}
              <FormField
                control={preferencesForm.control}
                name="foodPreferences"
                render={() => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2 text-base">
                      <Utensils className="h-4 w-4" />
                      Food Preferences
                    </FormLabel>
                    <FormDescription>Select your dietary preferences and food interests</FormDescription>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {foodOptions.map((option) => (
                        <FormField
                          key={option}
                          control={preferencesForm.control}
                          name="foodPreferences"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(option)}
                                  onCheckedChange={(checked) => {
                                    const currentValue = field.value || [];
                                    return checked
                                      ? field.onChange([...currentValue, option])
                                      : field.onChange(currentValue.filter((value: string) => value !== option))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="text-sm font-normal">{option}</FormLabel>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                  </FormItem>
                )}
              />

              {/* Themes */}
              <FormField
                control={preferencesForm.control}
                name="themes"
                render={() => (
                  <FormItem>
                    <FormLabel className="flex items-center gap-2 text-base">
                      <Compass className="h-4 w-4" />
                      Travel Themes & Interests
                    </FormLabel>
                    <FormDescription>What kind of experiences are you looking for?</FormDescription>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                      {themeOptions.map((option) => (
                        <FormField
                          key={option}
                          control={preferencesForm.control}
                          name="themes"
                          render={({ field }) => (
                            <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                              <FormControl>
                                <Checkbox
                                  checked={field.value?.includes(option)}
                                  onCheckedChange={(checked) => {
                                    const currentValue = field.value || [];
                                    return checked
                                      ? field.onChange([...currentValue, option])
                                      : field.onChange(currentValue.filter((value: string) => value !== option))
                                  }}
                                />
                              </FormControl>
                              <FormLabel className="text-sm font-normal">{option}</FormLabel>
                            </FormItem>
                          )}
                        />
                      ))}
                    </div>
                  </FormItem>
                )}
              />
            </form>
          </Form>
        );

      case 5: // Review
        return (
          <Form {...additionalForm}>
            <form onSubmit={additionalForm.handleSubmit(onSubmit)} className="space-y-6">
              <div className="text-center mb-8">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Review Your Trip Details</h3>
                <p className="text-gray-600">Make sure everything looks good before we create your personalized itinerary</p>
              </div>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Trip Overview</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div><strong>Destination:</strong> {formData.destination?.destination}</div>
                    <div><strong>From:</strong> {formData.destination?.departureCity}</div>
                    <div><strong>Duration:</strong> {formData.duration?.startDate} to {formData.duration?.endDate}</div>
                    <div><strong>Budget:</strong> {formData.budget?.currency} {formData.budget?.amount}</div>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Travelers</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3 text-sm">
                    <div><strong>Adults:</strong> {formData.travelers?.adults}</div>
                    {formData.travelers?.children && formData.travelers.children.length > 0 && (
                      <div><strong>Children:</strong> Ages {formData.travelers.children.join(", ")}</div>
                    )}
                    {formData.travelers?.pets && (
                      <div><strong>Pets:</strong> {formData.travelers.petDetails || "Yes"}</div>
                    )}
                  </CardContent>
                </Card>
              </div>

              <FormField
                control={additionalForm.control}
                name="additionalRequests"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Additional Requests or Special Requirements</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Any special requests, accessibility needs, or specific things you'd like to include in your trip..."
                        className="min-h-[100px]"
                        {...field}
                      />
                    </FormControl>
                    <FormDescription>
                      Tell us about any special requirements, celebrations, or unique experiences you'd like
                    </FormDescription>
                  </FormItem>
                )}
              />
            </form>
          </Form>
        );

      default:
        return null;
    }
  };

  const recommendations = getRecommendations();

  return (
    <div className="max-w-6xl mx-auto">
      <StepIndicator 
        steps={STEPS} 
        currentStep={currentStep} 
        completedSteps={completedSteps} 
      />

      <div className="grid lg:grid-cols-3 gap-8 mt-8">
        <div className="lg:col-span-2">
          <Card className="backdrop-blur-lg bg-white/80 border-white/20 shadow-2xl">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-2xl">
                <Compass className="h-6 w-6 text-ocean-600" />
                {STEPS[currentStep]}
              </CardTitle>
              <CardDescription>
                Step {currentStep + 1} of {STEPS.length}
              </CardDescription>
            </CardHeader>
            
            <CardContent>
              {renderStepContent()}
              
              <div className="flex justify-between pt-6">
                <Button
                  type="button"
                  variant="outline"
                  onClick={prevStep}
                  disabled={currentStep === 0}
                  className="flex items-center gap-2"
                >
                  <ChevronLeft className="w-4 h-4" />
                  Previous
                </Button>
                
                {currentStep === STEPS.length - 1 ? (
                  <Button 
                    type="button" 
                    onClick={() => additionalForm.handleSubmit(onSubmit)()}
                    size="lg" 
                    className="px-8"
                  >
                    Create My Trip Plan
                  </Button>
                ) : (
                  <Button
                    type="button"
                    onClick={nextStep}
                    className="flex items-center gap-2"
                  >
                    Next
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="lg:col-span-1">
          {recommendations.length > 0 && (
            <RecommendationCard 
              recommendations={recommendations}
              onSelect={(rec) => {
                console.log("Selected recommendation:", rec);
                // Handle recommendation selection
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};