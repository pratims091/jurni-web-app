import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { 
  MessageSquare, 
  Wand2, 
  Send,
  ArrowRight
} from "lucide-react";

const steps = [
  {
    icon: MessageSquare,
    number: "01",
    title: "Tell Us Your Preferences",
    description: "Share your travel style, interests, budget, and destination preferences with our AI assistant."
  },
  {
    icon: Wand2,
    number: "02", 
    title: "AI Creates Your Itinerary",
    description: "Our advanced AI analyzes thousands of options to craft a personalized travel plan just for you."
  },
  {
    icon: Send,
    number: "03",
    title: "Book & Enjoy Your Trip",
    description: "Review, customize, and book your perfect trip. Then enjoy your adventure with real-time support."
  }
];

const HowItWorksSection = () => {
  return (
    <section className="py-24 px-6 bg-gradient-to-br from-primary/5 to-secondary/5">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            How It Works
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Getting your perfect trip planned is as easy as having a conversation. 
            Let our AI do the heavy lifting while you dream about your next adventure.
          </p>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <Card className="h-full hover:shadow-warm transition-all duration-300 hover:-translate-y-1 border-primary/10">
                <CardContent className="p-8 text-center">
                  <div className="relative mb-8">
                    <div className="w-20 h-20 bg-gradient-hero rounded-full flex items-center justify-center mx-auto mb-4">
                      <step.icon className="w-10 h-10 text-white" />
                    </div>
                    
                    <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-sunset rounded-full flex items-center justify-center text-white font-bold text-sm">
                      {step.number}
                    </div>
                  </div>
                  
                  <h3 className="text-2xl font-semibold text-foreground mb-4">
                    {step.title}
                  </h3>
                  
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </CardContent>
              </Card>
              
              {/* Arrow connector (hidden on mobile) */}
              {index < steps.length - 1 && (
                <div className="hidden lg:block absolute top-1/2 -right-4 transform -translate-y-1/2 z-10">
                  <ArrowRight className="w-8 h-8 text-primary/30" />
                </div>
              )}
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <Button variant="hero" size="lg" className="text-lg px-12 py-6">
            Start Your Journey Today
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
          
          <p className="text-sm text-muted-foreground mt-4">
            Join thousands of happy travelers who've discovered their perfect trips
          </p>
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;