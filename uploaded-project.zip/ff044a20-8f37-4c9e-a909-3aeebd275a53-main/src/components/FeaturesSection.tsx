import { Card, CardContent } from "@/components/ui/card";
import { 
  Brain, 
  MapPin, 
  Calendar, 
  DollarSign, 
  Users, 
  Clock,
  Star,
  Globe
} from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "AI-Powered Planning",
    description: "Our advanced AI understands your preferences and creates personalized itineraries tailored just for you."
  },
  {
    icon: MapPin,
    title: "Hidden Gems Discovery",
    description: "Find authentic local experiences and off-the-beaten-path destinations that typical tourists miss."
  },
  {
    icon: Calendar,
    title: "Smart Scheduling",
    description: "Optimize your time with intelligent scheduling that considers travel times, opening hours, and crowd patterns."
  },
  {
    icon: DollarSign,
    title: "Budget Optimization",
    description: "Get the most value from your travel budget with AI-suggested alternatives and cost-saving tips."
  },
  {
    icon: Users,
    title: "Group Coordination",
    description: "Seamlessly plan trips for groups with shared itineraries and collaborative decision-making tools."
  },
  {
    icon: Clock,
    title: "Real-time Adjustments",
    description: "Adapt your plans on-the-go with real-time updates for weather, events, and unexpected changes."
  }
];

const FeaturesSection = () => {
  return (
    <section className="py-24 px-6 bg-gradient-to-br from-background to-muted/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary mb-6">
            <Star className="w-4 h-4" />
            <span className="text-sm font-medium">Why Choose AI Travel Planning</span>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Travel Smarter with
            <span className="block bg-gradient-hero bg-clip-text text-transparent">
              Intelligent Features
            </span>
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Experience the future of travel planning with our comprehensive AI-powered platform 
            that handles every detail of your journey.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="group hover:shadow-glow transition-all duration-300 hover:-translate-y-2 border-primary/10 hover:border-primary/30"
            >
              <CardContent className="p-8">
                <div className="w-14 h-14 bg-gradient-hero rounded-xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300">
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                
                <h3 className="text-xl font-semibold text-foreground mb-4">
                  {feature.title}
                </h3>
                
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="text-center mt-16">
          <div className="inline-flex items-center gap-4 text-muted-foreground">
            <Globe className="w-5 h-5" />
            <span>Trusted by travelers in 190+ countries worldwide</span>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;